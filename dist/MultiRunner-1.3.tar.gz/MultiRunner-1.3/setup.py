from setuptools import setup, find_packages
setup(
    name = "MultiRunner",
    version = "1.3",
    url='https://www.python.org/sigs/distutils-sig/',
    author = "Statham",
    author_email = "statham.stone@gmail.com",
    packages=[""]
)
