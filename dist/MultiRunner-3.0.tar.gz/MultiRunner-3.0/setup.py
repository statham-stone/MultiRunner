from setuptools import setup, find_packages
setup(
    name = "MultiRunner",
    version = "3.0",
    description= "",
    long_description= "This is a package for multi-process running, dedicated to my girlfriend 10L",
    url='https://www.github.com/statham-stone/',
    author = "Statham",
    author_email = "statham.stone@gmail.com",
    packages=[""]
)
