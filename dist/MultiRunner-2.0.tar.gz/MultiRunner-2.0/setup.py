from setuptools import setup, find_packages
setup(
    name = "MultiRunner",
    version = "2.0",
    url='https://www.github.com/statham-stone/',
    author = "Statham",
    author_email = "statham.stone@gmail.com",
    packages=[""]
)
