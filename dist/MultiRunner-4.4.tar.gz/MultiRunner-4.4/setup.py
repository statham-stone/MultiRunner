from setuptools import setup, find_packages
setup(
    name = "MultiRunner",
    version = "4.4",
    description= "Change default parameter if_log to True",
    long_description= "This is a package for multi-process running, dedicated to my girlfriend 10L",
    url='https://github.com/Statham-stone/MultiRunner',
    author = "Statham",
    author_email = "statham.stone@gmail.com",
    packages=[""]
)
