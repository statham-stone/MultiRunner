from setuptools import setup, find_packages
setup(
    name = "MultiRunner",
    version = "4.5",
    description= "This is a python package for multi-process running.",
    long_description= "This is a package for multi-process running, dedicated to my girlfriend 10L",
    url='https://github.com/Statham-stone/MultiRunner',
    author = "Statham",
    author_email = "statham.stone@gmail.com",
    packages=[""]
)
