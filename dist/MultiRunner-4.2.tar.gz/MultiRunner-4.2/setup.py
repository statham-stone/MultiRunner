from setuptools import setup, find_packages
setup(
    name = "MultiRunner",
    version = "4.2",
    description= "Change class name, change some method to private method.",
    long_description= "This is a package for multi-process running, dedicated to my girlfriend 10L",
    url='https://github.com/Statham-stone/MultiRunner',
    author = "Statham",
    author_email = "statham.stone@gmail.com",
    packages=[""]
)
